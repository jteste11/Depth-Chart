using System;
using System.Net;
using System.Threading.Tasks;
using System.Numerics;
using BaseballSharp;
using BaseballSharp.Enums;
using BaseballSharp.Models;

//jon tester
//jteste11@stumail.northeaststate.edu

//this is a project that will use an api to pull the current depth charts of MLB teams
namespace BaseballDepthChart
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        /// <summary>
        /// loads form. loads team using LoadTeamsAsync. adds team list to comboBox. 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void Form1_Load(object sender, EventArgs e)
        {
            dataGridView1.Visible = false; //start dataGridView1 invisible
            try
            {
                var teamsList = await LoadTeamsAsync();
                if (teamsList == null || !teamsList.Any()) //make sure teams load
                {
                    MessageBox.Show("No teams were retrieved.");
                    return;
                }
                comboBoxTeams.DataSource = teamsList.ToList();
                comboBoxTeams.DisplayMember = "FullName"; // Adjust based on team name property
                comboBoxTeams.ValueMember = "Id"; // Adjust based on team ID property
                comboBoxTeams.Refresh();
                FormatDataGridView();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to load teams: {ex.Message}");
            }
        }
        /// <summary>
        /// event that loads the depth chart into dataGridView1 after user selects show team button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void button1_Click(object sender, EventArgs e)
        {
            if (comboBoxTeams.SelectedItem == null) return;

            int teamId = (int)comboBoxTeams.SelectedValue; //changes team info based on user selection
            
            try
            {
                var teamRoster = await LoadRosterAsync(teamId);
                dataGridView1.DataSource = teamRoster; //loads depth chart into dataGridView1
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to load roster: {ex.Message}");
            }
            if (dataGridView1.Rows.Count > 0)
            {
                dataGridView1.Visible = true; //dataGridView1 becomes visible as rows are added
            }
        }
        /// <summary>
        /// Fetches team data using baseballsharp API.
        /// </summary>
        /// <returns></returns>
        private async Task<IEnumerable<Team>> LoadTeamsAsync()
        {
            var mlbClient = new BaseballSharp.MLBClient();
            return await mlbClient.GetTeamDataAsync();
        }
        /// <summary>
        /// Fetches team roster from baseballsharp API. returns roster as list.
        /// </summary>
        /// <param name="teamId"></param>
        /// <returns></returns>
        private async Task<IEnumerable<TeamRoster>> LoadRosterAsync(int teamId)
        {
            var mlbClient = new BaseballSharp.MLBClient();
            return (List<TeamRoster>)await mlbClient.GetTeamRosterAsync(teamId, 2025, DateTime.Now, BaseballSharp.Enums.rosterType.rosterFull);
        }
        /// <summary>
        /// autogenerates columns in DataGridView
        /// </summary>
        private void FormatDataGridView()
        {
            dataGridView1.AutoGenerateColumns = true;
        }
    }
}
